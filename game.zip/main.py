import pygame, controls
from cat import Cat
from pygame.sprite import Group
from stats import Stats
from scores import Scoures


def run(): # game start
  pygame.init()
  screen = pygame.display.set_mode((700, 600))
  pygame.display.set_caption("gaaaame")
  bg_color = (250, 218, 221)
  cat = Cat(screen) #вместо gun
  bullets = Group() #пули
  fishes = Group() #вместо пришельцев
  controls.create_army(screen, fishes)
  stats = Stats()
  sc = Scoures(screen, stats)

  while True:
    controls.events(screen, cat, bullets)
    if stats.run_game:
      cat.update_cat()
      controls.update(bg_color, screen, cat, fishes, bullets, stats, sc)
      controls.update_bullets(fishes, bullets, stats, sc)
      controls.update_fish(stats, screen, cat, fishes, bullets, sc)

run()

#если по простому, то вместо gun - cat, вместо ino - fish. функции подписала также как у него на видео. файлы названы точно также, только вместо gun - cat, вместо ino - fish. файл stats тоже есть ^^