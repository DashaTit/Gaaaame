import pygame, sys
from bullet import Bullet
from fish import Fish
import time
from pygame import mixer


def events(screen, cat, bullets):
  '''обработка нажатий клавиш'''
  for event in pygame.event.get():
      if event.type == pygame.QUIT:
        sys.exit()

      elif event.type == pygame.KEYDOWN:
          if event.key == pygame.K_d:
            cat.mright = True
          elif event.key == pygame.K_a:
            cat.mleft = True
          elif event.key == pygame.K_SPACE:
              new_bullet = Bullet(screen, cat)
              bullets.add(new_bullet)
              mixer.music.load("music/cat.mp3")
              mixer.music.set_volume(0.2)
              mixer.music.play()
      elif event.type == pygame.KEYUP:
          if event.key == pygame.K_d:
              cat.mright = False
          elif event.key == pygame.K_a:
              cat.mleft = False


def update(bg_color, screen, cat, fishes, bullets, stats, sc):
    '''обновление экрана'''
    screen.fill(bg_color)
    sc.show_score()
    for bullet in bullets.sprites():
        bullet.draw_bullet()
    cat.output()
    fishes.draw(screen)
    pygame.display.flip()


def update_bullets(fishes, bullets, stats, sc):
    '''обновление позиции пуль'''
    bullets.update()
    for bullet in bullets.copy():
        if bullet.rect.bottom <= 0:
          bullets.remove(bullet)
    collisions = pygame.sprite.groupcollide(bullets, fishes, True, True)
    if collisions:
        for fishes in collisions.values():
            stats.score += 10 * len(fishes)
        sc.image_score()
        check_high_score(stats, sc)
        sc.image_lives()


def update_fish(stats, screen, cat, fishes, bullets, sc):
    fishes.update()
    if pygame.sprite.spritecollideany(cat, fishes):
        cat_kill(stats, screen, cat, fishes, bullets, sc)


def create_army(screen, fishes):
    '''создание армии рыбок'''
    fish = Fish(screen)
    fish_width = fish.rect.width
    number_fish_x = int((700 - 2 * fish_width) / fish_width)
    fish_height = fish.rect.height
    number_fish_y = int((600 - 100 - 2*fish_height) / fish_height)

    for row in range(number_fish_y - 1):
        for fish_number in range(number_fish_x):
            fish = Fish(screen)
            fish.x = fish_width + fish_width * fish_number
            fish.y = fish_height + fish_height * row
            fish.rect.x = fish.x
            fish.rect.y = fish.rect.height + fish.rect.height * row
            fishes.add(fish)


def cat_kill(stats, screen, cat, fishes, bullets, sc):
    '''столкновение кота и рыбок'''
    if stats.cats_left > 0:
        stats.cats_left -= 1
        fishes.empty()
        bullets.empty()
        sc.image_lives()
        create_army(screen, fishes)
        cat.create_cat()
        time.sleep(2)
    else:
        stats.run_game = False
        sys.exit()


def check_high_score(stats, sc):
    if stats.score > stats.high_score:
        stats.high_score = stats.score
        sc.image_high_score()
        with open("highscore.txt", "w") as f:
            f.write(str(stats.high_score))
