import pygame, controls
from cat import Cat
from pygame.sprite import Group
from stats import Stats


def run(): # game start
  pygame.init()
  screen = pygame.display.set_mode((700, 600))
  pygame.display.set_caption("gaaaame")
  bg_color = (250, 218, 221)
  cat = Cat(screen) #вместо gun
  bullets = Group() #пули
  fishes = Group() #вместо пришельцев
  controls.create_army(screen, fishes)
  stats = Stats()



  while True:
    controls.events(screen, cat, bullets)
    cat.update_cat()
    controls.update(bg_color, screen, cat, fishes, bullets)
    controls.update_bullets(fishes, bullets)
    controls.update_fish(stats, screen, cat, fishes, bullets)

run()

#если по простому, то вместо gun - cat, вместо ino - fish. функции подписала также как у него на видео. файлы названы точно также, только вместо gun - cat, вместо ino - fish. файл stats тоже есть