class Stats():
  def __init__(self):
    self.reset_stats()

  def reset_stats(self):
    self.cats_left = 2